CREATE DATABASE ci;

USE ci;

CREATE TABLE production_company(
	p_id CHAR(5) NOT NULL UNIQUE,
   	p_name VARCHAR(40) NOT NULL,
    headquarters VARCHAR(50),
    ownerof VARCHAR(35) NOT NULL,
    PRIMARY KEY(p_id)
);

INSERT INTO production_company(p_id,p_name,headquarters,ownerof) VALUES ("","YASH RAJ FILMS","MUMBAI","YASH CHOPRA");
INSERT INTO production_company(p_id,p_name,headquarters,ownerof) VALUES ("qw125","2D Entertainment","CHENNAI","SURIYA");
INSERT INTO production_company(p_id,p_name,headquarters,ownerof) VALUES ("qw126","Ajay Devgn Films","MUMBAI","AAY DEVGAN");
INSERT INTO production_company(p_id,p_name,headquarters,ownerof) VALUES ("qw127","Anurag Kashyap Films","MUMBAI","Anurag Kashyap");
INSERT INTO production_company(p_id,p_name,headquarters,ownerof) VALUES ("qw128","Bhansali Productions","MUMBAI","SANAY L. BHANSALI");

CREATE TABLE theatre(
	t_id CHAR(5) NOT NULL UNIQUE,
    t_name VARCHAR(40) NOT NULL,
    locations VARCHAR(40) NOT NULL,
    PRIMARY KEY(t_id)
);

INSERT INTO theatre(t_id,t_name,locations) VALUES ("tk012","YASH RAJ CINEMA","MUMBAI");
INSERT INTO theatre(t_id,t_name,locations) VALUES ("tk011","2D Entertainment","CHENNAI");
INSERT INTO theatre(t_id,t_name,locations) VALUES ("tk014","TALKIES Films","MUMBAI");
INSERT INTO theatre(t_id,t_name,locations) VALUES ("tk015","COMPLEX THEATRE","MUMBAI");
INSERT INTO theatre(t_id,t_name,locations) VALUES ("tk016","RA MANDIR","MUMBAI");

CREATE TABLE movie(
  	m_id  CHAR(5) NOT NULL UNIQUE,
   	m_name VARCHAR(40) NOT NULL,
    pr_id CHAR(5) NOT NULL,
    th_id CHAR(5) NOT NULL,
    PRIMARY KEY(m_id),
    FOREIGN KEY(pr_id) REFERENCES production_company(p_id),
    FOREIGN KEY(th_id) REFERENCES theatre(t_id)
);

INSERT INTO movie(m_id,m_name,pr_id,th_id) VALUES ("mo124","RAZZ","qw124","tk012");
INSERT INTO movie(m_id,m_name,pr_id,th_id) VALUES ("mo124","DHOOM","qw124","tk012");
INSERT INTO movie(m_id,m_name,pr_id,th_id) VALUES ("mo124","PK","qw124","tk015");
INSERT INTO movie(m_id,m_name,pr_id,th_id) VALUES ("mo124","ABCD","qw124","tk015");
INSERT INTO movie(m_id,m_name,pr_id,th_id) VALUES ("mo124","KAMASUTRA","qw124","tk016");

CREATE TABLE tickets(
    ticket_id INT(10) NOT NULL UNIQUE,
    movie_date DATE NOT NULL,
    movie_time TIME NOT NULL,
    th_id CHAR(5) NOT NULL,
    movie_id CHAR(5) NOT NULL,
    PRIMARY KEY(ticket_id),
    FOREIGN KEY(th_id) REFERENCES theatre(t_id),
    FOREIGN KEY(movie_id) REFERENCES movie(m_id)
);

INSERT INTO tickets(ticket_id,movie_date,movie_time,th_id,movie_id) VALUES ("8765421000","2022-02-15","10:01:00","tk012","mo124");
INSERT INTO tickets(ticket_id,movie_date,movie_time,th_id,movie_id) VALUES ("8765421001","2022-02-10","10:10:00","tk012","mo124");
INSERT INTO tickets(ticket_id,movie_date,movie_time,th_id,movie_id) VALUES ("8765421002","2022-02-18","11:01:00","tk015","mo124");
INSERT INTO tickets(ticket_id,movie_date,movie_time,th_id,movie_id) VALUES ("8765421004","2022-02-17","12:01:00","tk015","mo124");
INSERT INTO tickets(ticket_id,movie_date,movie_time,th_id,movie_id) VALUES ("8765421005","2022-02-16","14:01:00","tk016","mo124");

CREATE TABLE seats(
  	seat_no INT(5) NOT NULL UNIQUE,
    th_id CHAR(5) NOT NULL,
    availabilityy VARCHAR(20) NOT NULL,
    seat_type CHAR(1) NOT NULL,
    CONSTRAINT PRIMARY KEY(seat_no, th_id),
    FOREIGN KEY(th_id) REFERENCES theatre(t_id)
);

INSERT INTO seats(seat_no,th_id,availabilityy,seat_type) VALUES ("87652","tk012","YES","G");
INSERT INTO seats(seat_no,th_id,availabilityy,seat_type) VALUES ("87678","tk012","YES","G");
INSERT INTO seats(seat_no,th_id,availabilityy,seat_type) VALUES ("87426","tk015","YES","G");
INSERT INTO seats(seat_no,th_id,availabilityy,seat_type) VALUES ("87620","tk015","YES","G");
INSERT INTO seats(seat_no,th_id,availabilityy,seat_type) VALUES ("87654","tk016","YES","G");

CREATE TABLE actors(
    a_id CHAR(5) NOT NULL UNIQUE,
    a_name VARCHAR(40) NOT NULL,
    PRIMARY KEY(a_id)
);

INSERT INTO actors(a_id,a_name) VALUES ("ABCDE","Akshay");
INSERT INTO actors(a_id,a_name) VALUES ("ABCDF","Akash");
INSERT INTO actors(a_id,a_name) VALUES ("ABCDG","Asaram");
INSERT INTO actors(a_id,a_name) VALUES ("ABCDH","Asneet");
INSERT INTO actors(a_id,a_name) VALUES ("ABCDI","Aay");


CREATE TABLE directors(
    d_id CHAR(5) NOT NULL UNIQUE,
    d_name VARCHAR(40) NOT NULL,
    PRIMARY KEY(d_id)
);

INSERT INTO directors(d_id,d_name) VALUES ("ABBDE","Ranikant");
INSERT INTO directors(d_id,d_name) VALUES ("ABBDF","SS Raamouli");
INSERT INTO directors(d_id,d_name) VALUES ("ABBDG","Karan cohar");
INSERT INTO directors(d_id,d_name) VALUES ("ABBDH","Ra Chopra");
INSERT INTO directors(d_id,d_name) VALUES ("ABBDI","Aay Devgan");

CREATE TABLE customer(
	c_id CHAR(5) NOT NULL UNIQUE,
    c_name VARCHAR(40) NOT NULL,
    email VARCHAR(25),
    tkt_id INT(10) NOT NULL UNIQUE,
    FOREIGN KEY(tkt_id) REFERENCES tickets(ticket_id),
    PRIMARY KEY(c_id)
);

INSERT INTO customer(c_id,c_name,email,tkt_id) VALUES ("vBCDE","Akshay","asd@gmail.com","87650");
INSERT INTO customer(c_id,c_name,email,tkt_id) VALUES ("vBCDF","Akash","akash@gmail.com","87651");
INSERT INTO customer(c_id,c_name,email,tkt_id) VALUES ("vBCDG","Asaram","asaram@gmail.com","87652");
INSERT INTO customer(c_id,c_name,email,tkt_id) VALUES ("vBCDH","Asneet","asneet@gmail.com","87654");
INSERT INTO customer(c_id,c_name,email,tkt_id) VALUES ("vBCDI","Aay","abhay@gmail.com","87655");


CREATE TABLE payment(
	ref_id CHAR(5) NOT NULL UNIQUE,
    payment_type VARCHAR(40) NOT NULL,
    payment_status VARCHAR(25) NOT NULL,
    payment_date DATE NOT NULL,
    amount FLOAT NOT NULL,
    cm_id CHAR(5) NOT NULL,
    PRIMARY KEY(ref_id),
    FOREIGN KEY(cm_id) REFERENCES customer(c_id)
);

INSERT INTO payment(ref_id,payment_type,payment_status,payment_date,amount,cm_id) VALUES ("PMT01","CASH","YES","2022-02-15",50.00,"vBCDE");
INSERT INTO payment(ref_id,payment_type,payment_status,payment_date,amount,cm_id) VALUES ("PMT02","CARD","PENDING","2022-02-15",400.00,"vBCDF");
INSERT INTO payment(ref_id,payment_type,payment_status,payment_date,amount,cm_id) VALUES ("PMT03","UPI","PENDING","2022-02-15",250.00,"vBCDG");
INSERT INTO payment(ref_id,payment_type,payment_status,payment_date,amount,cm_id) VALUES ("PMT04","DEBIT CARD","FAILED","2022-02-15",120.00,"vBCDH");
INSERT INTO payment(ref_id,payment_type,payment_status,payment_date,amount,cm_id) VALUES ("PMT05","EMI","SUCCESSFUL","2022-02-15",100.00,"vBCDI");

CREATE TABLE genre(
	m_id CHAR(5) NOT NULL,
    genre VARCHAR(10) NOT NULL UNIQUE,
    CONSTRAINT PRIMARY KEY(m_id, genre),
    FOREIGN KEY(m_id) REFERENCES movie(m_id)
);


INSERT INTO genre(m_id,genre) VALUES ("mo124","HORROR");
INSERT INTO genre(m_id,genre) VALUES ("mo124","DRAMA");
INSERT INTO genre(m_id,genre) VALUES ("mo124","COMEDY");
INSERT INTO genre(m_id,genre) VALUES ("mo124","ROMANCE");
INSERT INTO genre(m_id,genre) VALUES ("mo124","THRILLER");

CREATE TABLE act_ph(
	a_id CHAR(5) NOT NULL UNIQUE,
    ph_no INT(10) NOT NULL,
    CONSTRAINT PRIMARY KEY(a_id, ph_no),
    FOREIGN KEY(a_id) REFERENCES actors(a_id)
);


INSERT INTO act_ph(a_id,ph_no) VALUES ("ABCDE","8107054864");
INSERT INTO act_ph(a_id,ph_no) VALUES ("ABCDF","8765000124");
INSERT INTO act_ph(a_id,ph_no) VALUES ("ABCDG","4765000124");
INSERT INTO act_ph(a_id,ph_no) VALUES ("ABCDH","6765000124");
INSERT INTO act_ph(a_id,ph_no) VALUES ("ABCDI","5765000124");

CREATE TABLE direct_ph(
	d_id CHAR(5) NOT NULL UNIQUE,
    ph_no INT(10) NOT NULL,
    CONSTRAINT PRIMARY KEY(d_id, ph_no),
    FOREIGN KEY(d_id) REFERENCES directors(d_id)
);


INSERT INTO direct_ph(d_id,ph_no) VALUES ("ABBDE","5765002124");
INSERT INTO direct_ph(d_id,ph_no) VALUES ("ABBDF","5645000124");
INSERT INTO direct_ph(d_id,ph_no) VALUES ("ABBDG","6765000124");
INSERT INTO direct_ph(d_id,ph_no) VALUES ("ABBDH","2765000124");
INSERT INTO direct_ph(d_id,ph_no) VALUES ("ABBDI","5765111124");

CREATE TABLE customer_ph(
	c_id CHAR(5) NOT NULL UNIQUE,
    cph_no INT(10) NOT NULL UNIQUE,
    CONSTRAINT PRIMARY KEY(c_id, cph_no),
    FOREIGN KEY(c_id) REFERENCES customer(c_id)
);

INSERT INTO customer_ph(c_id,cph_no) VALUES ("vBCDE","5765002124");
INSERT INTO customer_ph(c_id,cph_no) VALUES ("vBCDF","4765002124");
INSERT INTO customer_ph(c_id,cph_no) VALUES ("vBCDG","4765112124");
INSERT INTO customer_ph(c_id,cph_no) VALUES ("vBCDH","7765102124");
INSERT INTO customer_ph(c_id,cph_no) VALUES ("vBCDI","8765006664");

CREATE TABLE customer_ticket(
	c_id CHAR(5) NOT NULL UNIQUE,
    ticket_id INT(10) NOT NULL UNIQUE ,
    CONSTRAINT PRIMARY KEY (ticket_id, c_id),
    FOREIGN KEY(c_id) REFERENCES customer(c_id),
    FOREIGN KEY(ticket_id) REFERENCES tickets(ticket_id)
    
);

INSERT INTO customer_ticket(c_id,ticket_id) VALUES ("vBCDE","87650");
INSERT INTO customer_ticket(c_id,ticket_id) VALUES ("vBCDF","87651");
INSERT INTO customer_ticket(c_id,ticket_id) VALUES ("vBCDG","87652");
INSERT INTO customer_ticket(c_id,ticket_id) VALUES ("vBCDH","87654");
INSERT INTO customer_ticket(c_id,ticket_id) VALUES ("vBCDI","87655");

CREATE TABLE acts_in(
    m_id CHAR(5) NOT NULL,
    a_id CHAR(5) NOT NULL,
    roll VARCHAR(30) NOT NULL,
    CONSTRAINT PRIMARY KEY(m_id, a_id),
    FOREIGN KEY(m_id) REFERENCES movie(m_id),
    FOREIGN KEY(a_id) REFERENCES actors(a_id)
);

INSERT INTO acts_in(m_id,a_id,roll) VALUES ("mo124","ABCDE","hero");
INSERT INTO acts_in(m_id,a_id,roll) VALUES ("mo124","ABCDF","villian");
INSERT INTO acts_in(m_id,a_id,roll) VALUES ("mo124","ABCDG","co hero");
INSERT INTO acts_in(m_id,a_id,roll) VALUES ("mo124","ABCDH","heroine");
INSERT INTO acts_in(m_id,a_id,roll) VALUES ("mo124","ABCDI","side hero");

CREATE TABLE directs_in(
    m_id CHAR(5) NOT NULL,
    d_id CHAR(5) NOT NULL,
    year INT(4) NOT NULL,
    CONSTRAINT PRIMARY KEY(m_id, d_id),
    FOREIGN KEY(m_id) REFERENCES movie(m_id),
    FOREIGN KEY(d_id) REFERENCES directors(d_id)
);

INSERT INTO directs_in(m_id,d_id,year) VALUES ("mo124","ABBDE",2022);
INSERT INTO directs_in(m_id,d_id,year) VALUES ("mo124","ABBDF",2005);
INSERT INTO directs_in(m_id,d_id,year) VALUES ("mo124","ABBDG",2004);
INSERT INTO directs_in(m_id,d_id,year) VALUES ("mo124","ABBDH",2007);
INSERT INTO directs_in(m_id,d_id,year) VALUES ("mo124","ABBDI",2008);

ALTER TABLE payment ADD UNIQUE (ref_id);
DELETE FROM seats WHERE seat_no = "87652";
UPDATE customer SET email = "deabu200@gmail.com" WHERE c_id = "vBCDE";

SELECT m_name
FROM movie
WHERE EXISTS
(SELECT * FROM theatre WHERE theatre.t_id = movie.th_id);

CREATE VIEW PC as
SELECT p_name, headquarters
FROM production_company
WHERE p_id = "qw125";

DROP VIEW PC;

SELECT MIN (amount) FROM (payment);
SELECT MAX (amount) FROM (payment);
SELECT COUNT (c_id) FROM (customer);

ALTER TABLE `seats`
  MODIFY `seat_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;